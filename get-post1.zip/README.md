## How to Run
Clone the project and unzip the files.

Go to the project folder(package.json should be there in the current directory).

Now run the command "npm install".

You are ready to go. Run "npm start".

Go to http://localhost:3000/. The application should load the search bar and map centered with current location(Try refresh).

## Built With

* [React]https://reactjs.org/

