export const SET_USERS = 'SET_USERS';
export const SET_POSTS = 'SET_POSTS';
export const ADD_POST = 'ADD_POST';