const Wrap = (props) => props.children

export default Wrap;